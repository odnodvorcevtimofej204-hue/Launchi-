package com.nexus.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ClipData
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 18)
    private val panel = Color.rgb(25, 29, 43)
    private val accent = Color.rgb(112, 145, 255)
    private var drawerOpen = false
    private val prefs by lazy { getSharedPreferences("nexus_settings", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun drawerColumns(): Int = prefs.getInt("drawer_columns", 4).coerceIn(3, 5)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        ensureInitialPins()
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 28f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun launcherApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun homeSlots(): MutableList<String> {
        val raw = prefs.getString("home_slots", null) ?: return mutableListOf()
        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { index -> array.optString(index, "") }
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    private fun saveHomeSlots(slots: List<String>) {
        val trimmed = slots.toMutableList()
        while (trimmed.isNotEmpty() && trimmed.last().isBlank()) trimmed.removeAt(trimmed.lastIndex)
        prefs.edit().putString("home_slots", JSONArray(trimmed).toString()).apply()
    }

    private fun ensureInitialPins() {
        if (prefs.contains("home_slots")) return
        val apps = launcherApps()
        val chosen = mutableListOf<String>()
        val groups = listOf(
            listOf("phone", "телефон", "dialer"),
            listOf("messages", "сообщения", "messaging", "sms"),
            listOf("camera", "камера"),
            listOf("settings", "настройки")
        )
        groups.forEach { words ->
            val match = apps.firstOrNull { info ->
                val label = info.loadLabel(packageManager).toString().lowercase(Locale.getDefault())
                words.any { label.contains(it) } && info.activityInfo.packageName !in chosen
            }
            if (match != null) chosen.add(match.activityInfo.packageName)
        }
        if (chosen.isEmpty()) chosen.addAll(apps.take(4).map { it.activityInfo.packageName })
        saveHomeSlots(chosen)
    }

    private fun appLabel(packageName: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
    } catch (_: Exception) { packageName.substringAfterLast('.') }

    private fun appIcon(packageName: String) = try {
        packageManager.getApplicationIcon(packageName)
    } catch (_: Exception) { null }

    private fun launch(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
            ?: Toast.makeText(this, "Приложение больше недоступно", Toast.LENGTH_SHORT).show()
    }

    private fun createShortcut(packageName: String?, slot: Int, isDock: Boolean): View {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(5), dp(3), dp(5))
            background = rounded(if (isDock) 0x332F477A else 0x1AFFFFFF, 18f)
            tag = packageName
        }

        if (!packageName.isNullOrBlank()) {
            val icon = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageDrawable(appIcon(packageName))
            }
            cell.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val label = text(appLabel(packageName), 10.5f, Color.WHITE)
            label.gravity = Gravity.CENTER
            label.maxLines = 1
            label.ellipsize = android.text.TextUtils.TruncateAt.END
            val labelLp = LinearLayout.LayoutParams(-1, dp(22))
            labelLp.topMargin = dp(3)
            cell.addView(label, labelLp)
            cell.setOnClickListener { launch(packageName) }
            cell.setOnLongClickListener { view ->
                val clip = ClipData.newPlainText("nexus-package", packageName)
                view.startDragAndDrop(clip, View.DragShadowBuilder(view), packageName, 0)
                true
            }
        } else {
            val plus = text("+", 25f, 0xFF8FA8FF.toInt())
            plus.gravity = Gravity.CENTER
            cell.addView(plus, LinearLayout.LayoutParams(dp(42), dp(42)))
            val label = text(if (isDock) "Добавить" else "Пусто", 9.5f, 0xFF9CA8C5.toInt())
            label.gravity = Gravity.CENTER
            cell.addView(label, LinearLayout.LayoutParams(-1, dp(22)))
        }

        cell.setOnDragListener { view, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> event.clipDescription?.label == "nexus-package"
                DragEvent.ACTION_DRAG_ENTERED -> {
                    view.background = rounded(0x665C7DDA, 18f)
                    true
                }
                DragEvent.ACTION_DRAG_EXITED -> {
                    view.background = rounded(if (isDock) 0x332F477A else 0x1AFFFFFF, 18f)
                    true
                }
                DragEvent.ACTION_DROP -> {
                    val draggedPackage = event.localState as? String
                    if (draggedPackage != null) {
                        moveShortcut(draggedPackage, slot)
                        true
                    } else false
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    view.background = rounded(if (isDock) 0x332F477A else 0x1AFFFFFF, 18f)
                    true
                }
                else -> true
            }
        }
        return cell
    }

    private fun moveShortcut(packageName: String, targetSlot: Int) {
        val slots = homeSlots()
        val sourceSlot = slots.indexOf(packageName)
        if (sourceSlot < 0 || sourceSlot == targetSlot) return
        while (slots.size <= targetSlot) slots.add("")
        val displaced = slots[targetSlot]
        slots[targetSlot] = packageName
        if (sourceSlot < slots.size) slots[sourceSlot] = displaced
        saveHomeSlots(slots)
        Toast.makeText(this, "Положение ярлыка сохранено", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun showHome() {
        drawerOpen = false
        val slots = homeSlots()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(14, 22, 43), bg, Color.rgb(23, 17, 43))
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text("NEXUS", 15f, Color.rgb(170, 190, 255), true),
            LinearLayout.LayoutParams(0, dp(38), 1f))
        val menu = text("⋮", 28f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showOptions() }
        }
        top.addView(menu, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(top)

        val clock = text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 54f, Color.WHITE, true)
        root.addView(clock)
        root.addView(text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()),
            15f, 0xFFB8C0D8.toInt()))

        val info = TextView(this).apply {
            text = "NEXUS OS  •  POCO M6"
            textSize = 13f
            setTextColor(0xFFD5DCF3.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(0x332F477A, 24f)
        }
        val infoLp = LinearLayout.LayoutParams(-1, dp(48))
        infoLp.topMargin = dp(16)
        root.addView(info, infoLp)

        val section = text("Рабочий стол", 16f, Color.WHITE, true)
        val sectionLp = LinearLayout.LayoutParams(-1, -2)
        sectionLp.topMargin = dp(17)
        sectionLp.bottomMargin = dp(8)
        root.addView(section, sectionLp)

        val pageSize = 16
        val contentCount = (slots.size - 4).coerceAtLeast(0)
        val pageCount = maxOf(1, ceil(contentCount / pageSize.toDouble()).toInt())
        val viewport = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            fillViewport = true
        }
        val pages = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pageWidth = resources.displayMetrics.widthPixels - dp(40)
        repeat(pageCount) { pageIndex ->
            val page = GridLayout(this).apply {
                columnCount = 4
                rowCount = 4
                useDefaultMargins = false
            }
            repeat(pageSize) { cellIndex ->
                val slot = 4 + pageIndex * pageSize + cellIndex
                val packageName = slots.getOrNull(slot)?.takeIf { it.isNotBlank() }
                val cell = createShortcut(packageName, slot, false)
                val lp = GridLayout.LayoutParams(
                    GridLayout.spec(cellIndex / 4, 1f),
                    GridLayout.spec(cellIndex % 4, 1f)
                ).apply {
                    width = 0
                    height = dp(82)
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                }
                page.addView(cell, lp)
            }
            val pageFrame = FrameLayout(this)
            pageFrame.addView(page, FrameLayout.LayoutParams(-1, dp(350), Gravity.CENTER))
            pages.addView(pageFrame, LinearLayout.LayoutParams(pageWidth, -1))
        }
        viewport.addView(pages)
        root.addView(viewport, LinearLayout.LayoutParams(-1, 0, 1f))

        val indicator = text((0 until pageCount).joinToString("   ") { if (it == 0) "●" else "○" },
            11f, 0xFF9EACD2.toInt())
        indicator.gravity = Gravity.CENTER
        root.addView(indicator, LinearLayout.LayoutParams(-1, dp(22)))
        viewport.setOnScrollChangeListener { _, scrollX, _, _, _ ->
            val current = (scrollX / pageWidth).coerceIn(0, pageCount - 1)
            indicator.text = (0 until pageCount).joinToString("   ") { if (it == current) "●" else "○" }
        }

        val dockTitle = text("DOCK", 10f, 0xFF9EACD2.toInt(), true)
        dockTitle.gravity = Gravity.CENTER
        root.addView(dockTitle, LinearLayout.LayoutParams(-1, dp(16)))
        val dock = GridLayout(this).apply { columnCount = 4 }
        repeat(4) { slot ->
            val pkg = slots.getOrNull(slot)?.takeIf { it.isNotBlank() }
            val cell = createShortcut(pkg, slot, true)
            dock.addView(cell, GridLayout.LayoutParams(
                GridLayout.spec(0, 1f), GridLayout.spec(slot, 1f)
            ).apply {
                width = 0
                height = dp(70)
                setMargins(dp(3), dp(2), dp(3), dp(2))
            })
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(76)))

        val drawerButton = TextView(this).apply {
            text = "Все приложения  ↑"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFFB9C8FF.toInt())
            setOnClickListener { showDrawer() }
        }
        root.addView(drawerButton, LinearLayout.LayoutParams(-1, dp(34)))
        setContentView(root)
    }

    private fun showDrawer() {
        drawerOpen = true
        val scroller = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 17, 31), bg)
            )
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("Приложения", 27f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, dp(56), 1f))
        header.addView(text("✕", 22f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showHome() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        list.addView(header)

        val search = EditText(this).apply {
            hint = "Поиск"
            setHintTextColor(0xFF9AA6C4.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine()
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(panel, 24f)
        }
        val searchLp = LinearLayout.LayoutParams(-1, dp(52))
        searchLp.topMargin = dp(10)
        list.addView(search, searchLp)

        val grid = GridLayout(this).apply { columnCount = drawerColumns() }
        val apps = launcherApps()
        fun populate(filter: String = "") {
            grid.removeAllViews()
            apps.filter { it.loadLabel(packageManager).toString().contains(filter, true) }
                .forEach { info ->
                    val packageName = info.activityInfo.packageName
                    val cell = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        setPadding(dp(3), dp(10), dp(3), dp(10))
                        val icon = ImageView(this@MainActivity)
                        icon.setImageDrawable(info.loadIcon(packageManager))
                        addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
                        val label = text(info.loadLabel(packageManager).toString(), 11f, Color.WHITE)
                        label.gravity = Gravity.CENTER
                        label.maxLines = 2
                        addView(label, LinearLayout.LayoutParams(-1, dp(36)))
                        setOnClickListener { launch(packageName) }
                        setOnLongClickListener {
                            val current = homeSlots()
                            if (packageName !in current) {
                                current.add(packageName)
                                saveHomeSlots(current)
                                Toast.makeText(this@MainActivity,
                                    "${info.loadLabel(packageManager)} добавлено на рабочий стол",
                                    Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "Уже на рабочем столе",
                                    Toast.LENGTH_SHORT).show()
                            }
                            true
                        }
                    }
                    grid.addView(cell, GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(100)
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    })
                }
        }
        populate()
        search.addTextChangedListener(SimpleWatcher { populate(it) })
        val gridLp = LinearLayout.LayoutParams(-1, -2)
        gridLp.topMargin = dp(18)
        list.addView(grid, gridLp)
        scroller.addView(list)
        setContentView(scroller)
    }

    private fun showGridSettings() {
        val choices = arrayOf("3 столбца", "4 столбца", "5 столбцов")
        AlertDialog.Builder(this)
            .setTitle("Сетка приложений")
            .setSingleChoiceItems(choices, drawerColumns() - 3) { dialog, which ->
                prefs.edit().putInt("drawer_columns", which + 3).apply()
                dialog.dismiss()
                showDrawer()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showOptions() {
        AlertDialog.Builder(this)
            .setTitle("NEXUS OS")
            .setItems(arrayOf("Все приложения", "Сетка приложений", "Обои",
                "Настройки Android", "О лаунчере")) { _, which ->
                when (which) {
                    0 -> showDrawer()
                    1 -> showGridSettings()
                    2 -> startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER))
                    3 -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    4 -> AlertDialog.Builder(this)
                        .setMessage("NEXUS OS 0.3.0\nЛаунчер для POCO M6 / Android 16.")
                        .setPositiveButton("OK", null).show()
                }
            }.show()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (drawerOpen) showHome() else super.onBackPressed()
    }
}

private class SimpleWatcher(val onChange: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        onChange(s?.toString() ?: "")
    }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
