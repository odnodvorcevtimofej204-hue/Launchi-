plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexus.launcher"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nexus.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0"
    }
    kotlinOptions { jvmTarget = "17" }
}
